let text = prompt("\
s - add to search bar\n\
    u - '-censored'\n\
    s - 'sort:score'\n\
a - open artists\n\
i - open original images\n\
d - download open images\n\
p - prepare for images", "p");
browser.runtime.sendMessage(text);
