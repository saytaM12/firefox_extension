let url = window.location.href;
let searchText;

if (url.includes("rule34") || url.includes("gelbooru")) {
    searchText = "Original image";
}
else if (url.includes("lolibooru")) {
    searchText = "Download larger version";
}

let aTags = document.querySelectorAll("a");
let found;

for (let i = 0; i < aTags.length; i++) {
    if (aTags[i].textContent.includes(searchText)) {
        found = aTags[i];
        break;
    }
}

let link = found.getAttribute("href");

window.open(link, "_self");
